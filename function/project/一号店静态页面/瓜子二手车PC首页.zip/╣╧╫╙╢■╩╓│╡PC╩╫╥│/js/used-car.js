/* var content = document.getElementsByClassName("main-content-1")[0];
var products = content.getElementsByTagName("li");
var back = ["automobile-1-2.png","automobile-2-2.png","automobile-3-2.png","automobile-4-2.png"]
console.log(products)
for(var i=0;i<products.length;i++){
	// products[i].index = i;
	products[i].onmouseover = function(){
		this.style.background="url(img/"+back[i]+")no-repeat";
		this.style.backgroundSize = "100% 100%";
	}
} */